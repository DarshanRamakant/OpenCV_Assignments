#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <iostream>
#include <stdio.h>

using namespace cv;
int main() {

	cv::Mat img = cv::imread("test14_4.jpg");
	if (!img.data) {
		std::cout << "Image file not found\n";
		return 1;
	}

	cv::Mat img_threshold;
// threshold image
	cv::cvtColor(img, img_threshold, CV_BGR2GRAY);
//cv::Canny(img_threshold,img_threshold,60,180,3);
//cv::GaussianBlur(img_threshold,img_threshold,cv::Size(5,5),2,2,BORDER_DEFAULT);
	cv::threshold(img_threshold, img_threshold, 140, 255, CV_THRESH_BINARY);

	cv::Mat binary;
//cv::erode(img_threshold,binary,cv::Mat(),cv::Point(-1,-1),10);
//cv::dilate(img_threshold,binary,cv::Mat(),cv::Point(1,1),1);
	binary = img_threshold.clone();
//Search contours

	cv::vector<cv::vector<cv::Point> > contours;
	cv::vector<cv::Point> points;

	cv::findContours(img_threshold, contours, 0, 2);

// polygons from contours
	cv::vector<cv::vector<cv::Point> > contours_poly(contours.size());
	cv::vector<cv::Rect> boundRect(contours.size());
	cv::vector<cv::Point2f> center(contours.size());
	cv::vector<float> radius(contours.size());

	for (int i = 0; i < (int) contours.size(); i++) {
		approxPolyDP(cv::Mat(contours[i]), contours_poly[i], 3, true);
//fitting them into rectangles
		boundRect[i] = cv::boundingRect(cv::Mat(contours_poly[i]));
	}

//Draw bounding rect

	cv::Mat drawing(img);
	for (int i = 0; i < (int) contours.size(); i++) {

		cv::Scalar color = cv::Scalar(0, 255, 0);
// Filtering out very small and very big rectangles
// It is assumed that the number plates in the images will be of almost constant sized rectangles.
		if (boundRect[i].height > 30 && boundRect[i].height < 60
				&& boundRect[i].width > 130 && boundRect[i].width < 230) //&& boundRect[i].width <200
						{
			rectangle(drawing, boundRect[i].tl(), boundRect[i].br(), color, 2,
					8, 0);
		}
	}

	imshow("Number Plate detected Image", img);

	cvWaitKey(0);

	return 0;

}
